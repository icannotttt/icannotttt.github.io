Clazz.declarePackage("JS");
Clazz.declareInterface(JS, "HTMLWindowEvent");
;//5.0.1-v7 Tue Jul 22 18:14:29 CDT 2025
