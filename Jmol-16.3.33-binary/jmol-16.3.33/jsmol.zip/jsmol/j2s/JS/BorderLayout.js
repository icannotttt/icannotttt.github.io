Clazz.declarePackage("JS");
Clazz.load(["JS.LayoutManager"], "JS.BorderLayout", null, function(){
var c$ = Clazz.declareType(JS, "BorderLayout", JS.LayoutManager);
});
;//5.0.1-v7 Tue Jul 22 18:14:29 CDT 2025
