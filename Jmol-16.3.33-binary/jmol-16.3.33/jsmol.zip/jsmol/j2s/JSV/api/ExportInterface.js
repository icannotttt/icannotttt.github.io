Clazz.declarePackage("JSV.api");
Clazz.declareInterface(JSV.api, "ExportInterface", JSV.api.JSVExporter);
;//5.0.1-v7 Tue Jul 22 18:14:29 CDT 2025
