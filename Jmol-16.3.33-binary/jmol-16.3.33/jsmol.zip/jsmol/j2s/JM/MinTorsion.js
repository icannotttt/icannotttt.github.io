Clazz.declarePackage("JM");
Clazz.load(["JM.MinObject"], "JM.MinTorsion", null, function(){
var c$ = Clazz.declareType(JM, "MinTorsion", JM.MinObject);
Clazz.makeConstructor(c$, 
function(data){
Clazz.superConstructor (this, JM.MinTorsion, []);
this.data = data;
}, "~A");
});
;//5.0.1-v7 Tue Jul 22 18:14:29 CDT 2025
